#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include "../include/leitura.h"
#include "../include/decifra2.h"

void testaParametros(int argc){
    if(argc != 2)
    { // indica ao usuário que apenas dois arquivo deve ser dados, caso contrario o programa é encerrado
        printf("Para passar o arquivo de forma correta: ./executável: <arquivo> <arquivo>");
        exit(0);
    }
}

void testaArq(FILE *arqUsers,const char *mode){
    if(arqUsers == NULL){
        printf("Arquivo vazio ou inexistente\n");
        exit(0);
    }
}

int main(int argc, char *argv[]){
    testaParametros(argc);

    FILE *cifra = fopen(argv[1], "r"); // abre o arquivo apenas para leitura
    testaArq(cifra, "r");


    char var[3][8] = {0}; // matriz apenas para saber o núm. de variáveis distintas
    //char varSystem[3][8] = {0}; // matrix com a estrutura da equação
    leitura(cifra, var);

    char variable[7] = ""; // vetor de variáveis únicas

    char compare;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 8; j++)
            {
            compare = var[i][j];
                for (int k = 0; k < 3; k++)
                {
                    for (int w = 0; w < 8; w++)
                    {
                        if(compare != var[k][w] && strchr(variable, compare) == NULL && strlen(variable) < 7){
                            strncat(variable, &var[i][j], 1);
                        }
                    }
                }
            }
        }

    int tam = strlen(variable); // núm. total variáveis
    variavel *lista = malloc(tam * sizeof(variavel));

    for (int i = 0; i < tam; i++)
    {
        lista[i].letra = variable[i];
        lista[i].valor = 9;
    }

    // criacao do sistema de equações com seus valores
    int varSystem[3][8] = {0};

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            for (int k = 0; k < tam; k++)
            {
                if(var[i][j] == lista[k].letra){
                    varSystem[i][j] = lista[k].valor;
                }
            }
        }
    }

    int result = 0;
    int number1 = 0;
    int number2 = 0;
    // declara pot de result, number1 e 2
    int potR = 0;
    int pot1 = 0;
    int pot2 = 0;

    for (int j = 0; j <8 ; j++) // result
    {
        potR = j;
            result = result + varSystem[2][j] * (pow(10,potR));
    }
    for (int j = 0; j <8 ; j++) // number1
    {
        potR = j;
            number1 = number1 + varSystem[0][j] * (pow(10,potR));
    }
    for (int j = 0; j <8 ; j++) // number2
    {
        potR = j;
            number2 = number2 + varSystem[1][j] * (pow(10,potR));
    }

    int somaAnt = number1+number2; // será usado no controle dos maiores valores das var

    int copiaNumero = result;
    int tamanhoResult;
     // Determina o tamanho do resultado
        while (copiaNumero > 0) {
            copiaNumero /= 10;
            tamanhoResult++;
        }


    int *maiores = malloc(tam * sizeof(int)); // irá guardar o maior valor das variáveis
    for(int i = 0; i < tam; i++)
    {
        maiores[i] = 0;
    }

    decifra2(somaAnt, number1, number2,potR ,pot1 ,pot2 , lista, tam, tam, var, varSystem, maiores, result, result, tamanhoResult);

    for (int i = 0; i < tam; i++)
    {
        printf("%c = %d\n", lista[i].letra, maiores[i]);
    }
    free(lista);
    free(maiores);
    return 0;
    // para rodar ./main ../cifra.txt
}