#include<stdio.h>
#include <math.h>
#include "../include/leitura.h"
#include "../include/decifra2.h"

void decifra2(int somaAnt ,int number1, int number2,int potR, int pot1, int pot2, variavel *lista, int tam, int tam_ori, char (*var)[8], int (*varSystem)[8], int *maiores, int result, int result_ori, int tamanhoResult){
// para poder calcular a potencia de 10 a qual o num. da variável esta sendo mult

    int soma = 0;
    int vetorResult[8] = {0};

    // equacao linear
    if(tam == 0)
    {   printf("Fim recursão\n");
        //imprime_solucao(x, n_original, c_original);
    }else{
    // torna o result (int) em vetor int p/ alterar o valor das var corretamente!
    int resultCopy = result;

    // Preenche o vetor com os dígitos
    for (int i = tamanhoResult - 1; i >= 0; i--)
    {
        vetorResult[i] = resultCopy % 10;
        resultCopy /= 10;
    }

    // atualizo variáveis que aparecem em resultado, independente de sua posição na matriz, as que são afetadas pela subtração!
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            for (int k = 0; k < tam_ori; k++)
            {
                if(var[2][j] == lista[k].letra)
                {
                   lista[k].valor = vetorResult[j];
    }}}}

    for (int j = 0; j < tamanhoResult; j++) // result
    {
        result = result + vetorResult[j] * (pow(10,potR));
    }

    //após subtração de 1 do result vamos alterar a variável atual para assumir todos os valores de 9 - 0 p/cmp. com result
    for(int p = 9; p >= 0; p--) // subtrai de acordo com p
    {lista[tam].valor = p;

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if(lista[tam].letra == var[i][j]){
                    varSystem[i][j] = lista[tam].valor;
                }
            }
        }

        // atribui novo valor p/soma
        for (int j = 0; j <8 ; j++)
        {
            number1 = number1 + varSystem[0][j] * (pow(10,pot1));
        }
        for (int j = 0; j <8 ; j++)
        {
            number2 = number2 + varSystem[1][j] * (pow(10,pot2));
        }
        soma = number1 + number2;

        if(soma == result)
        {
            if(maiores[tam] < p)
            {
                if(somaAnt < soma)
                {
                    for(int i = 0; i < tam_ori; i++)
                    {
                        maiores[i] = lista[i].valor;

        }}}printf("soma: %d result:%d\n", soma, result);}

        }decifra2(somaAnt, number1, number2, potR, pot1, pot2, lista, tam -1, tam, var, varSystem, maiores, result - 1, result_ori, tamanhoResult);
    }
}




