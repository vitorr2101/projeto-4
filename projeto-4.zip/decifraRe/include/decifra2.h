#ifndef _DECIFRA2_H
#define _DECIFRA2_H

void decifra2(int somaAnt, int number1, int number2, int potR, int pot1, int pot2, variavel *lista, int tam, int tam_ori, char (*var)[8],int (*varSystem)[8],int *maiores, int result, int result_ori, int tamanhoResult);

#endif