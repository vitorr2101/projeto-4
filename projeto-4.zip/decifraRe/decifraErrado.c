#include<stdio.h>
#include <math.h>
#include "../include/leitura.h"
#include "../include/decifra.h"

void decifra(variavel *lista, int tam, int tam_ori, char (*var)[8], int (*varSystem)[8], int *maiores, int result, int result_ori, int tamanhoResult){
// para poder calcular a potencia de 10 a qual o num. da variável esta sendo mult
    int pot = 7; // começa no maior valor possível
    int number1 = 0;
    int number2 = 0;
    int soma = 0;
    int vetorResult[8];

    // equacao linear
    if(tam == 0 )
    {   printf("Fim recursão\n");
        //imprime_solucao(x, n_original, c_original);
    }else{
        // preciso apos ter o resultado calculado o passar para um vetor,pois como estou lidando com uma
        // linha de matriz a cada recursão (no caso a 2) só é possível alterar seu valor se result for
        // interpretado como vetor, onde cada posicao representa uma var!
        int vetorResult[8] = {0};
        int resultCopy = result;

        // Preenche o vetor com os dígitos
        for (int i = tamanhoResult - 1; i >= 0; i--)
        {
            vetorResult[i] = resultCopy % 10;
            resultCopy /= 10;
        }

        for(int p = 9; p >= 0; p--)// subtrai o valor da var atual de acordo com p
        {lista[tam].valor = p;


        for (int i = 0; i < 3; i++) // atribui o valor das var de acordo com result
        {
            for (int j = 0; j < 8; j++)
            {
                if(var[i][j] == lista[tam].letra)
                {
                        varSystem[i][j] = lista[tam].valor;
        }}}

        for (int i = 0; i < 2; i++) // atribui o valor das var de acordo com result
        {
            for (int j = 0; j < 8; j++)
            {
                for (int k = 0; k < tam_ori; k++)
                {
                    if(var[2][j] == lista[k].letra){ // o for percorre todo o vetor de variáveis!! Pois pode ser que eu acabe mudando mais de uma variável por iteração

                        lista[k].valor = vetorResult[j];  // var recebe novo valor baseado no resultado -1 calculado
                        }
                        }}}

        for (int i = 0; i < 3; i++) // atribui o valor das var de acordo com result
        {
            for (int j = 0; j < 8; j++)
            {
                for (int k = 0; k < tam_ori; k++)
                {
                if(var[i][j] == lista[k].letra)
                {
                    varSystem[i][j] = lista[k].valor; // Monto o sistema linear
                }
                }
            }
        }

        // após atualização do valor de result, defino os num. para cálculo
        for(int e = 0; e < 3; e++)
        {
            for(int f = 0; f < 8; f++)
            { pot = f;
                if(e == 0)
                {
                    number1 = number1 + varSystem[e][f] * (pow(10,pot));
                }else if(e == 1)
                {
                    number2 = number2 + varSystem[e][f] * (pow(10,pot));
                }
                soma = number1 + number2;

                if(soma == result)
                    {
                        if(var[e][f] == lista[tam].letra)
                        {
                        if(maiores[tam] < varSystem[e][f])
                        {
                            maiores[tam] = varSystem[e][f];
                        }
                        }
                    }

                printf("soma: %d result:%d\n", soma, result);
            }

        } decifra(lista, tam -1, tam, var, varSystem, maiores, result - 1, result_ori, tamanhoResult);
    }
    }

    }



