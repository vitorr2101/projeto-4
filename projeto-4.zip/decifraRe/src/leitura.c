#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/leitura.h"

// retorna o vetor de struct
void leitura(FILE *cifra, char (*var)[8]){

    for (int i = 0; i < 3; i++) {
        fscanf(cifra, "%s", var[i]);  // Lê até 6 caracteres para deixar espaço para o caractere nulo
    }
    fclose(cifra);
}
