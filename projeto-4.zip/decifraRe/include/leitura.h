#ifndef _LEITURA_H
#define _LEITURA_H

typedef struct{
        char letra;
        int valor;
}variavel;

void leitura(FILE *cifra, char (*var)[8]);

#endif